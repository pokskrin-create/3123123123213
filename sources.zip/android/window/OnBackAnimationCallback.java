package android.window;

/* loaded from: classes2.dex */
public /* synthetic */ interface OnBackAnimationCallback extends OnBackInvokedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}
