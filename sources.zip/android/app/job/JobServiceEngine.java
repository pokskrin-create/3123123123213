package android.app.job;

/* loaded from: classes2.dex */
public /* synthetic */ class JobServiceEngine {
    static {
        throw new NoClassDefFoundError();
    }
}
