package android.app;

/* loaded from: classes2.dex */
public /* synthetic */ class AppComponentFactory {
    static {
        throw new NoClassDefFoundError();
    }
}
