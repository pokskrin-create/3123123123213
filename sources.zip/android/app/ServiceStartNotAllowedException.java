package android.app;

/* loaded from: classes2.dex */
public /* synthetic */ class ServiceStartNotAllowedException extends IllegalStateException {
    static {
        throw new NoClassDefFoundError();
    }
}
