package android.webkit;

/* loaded from: classes2.dex */
public /* synthetic */ class WebViewRenderProcessClient {
    static {
        throw new NoClassDefFoundError();
    }
}
