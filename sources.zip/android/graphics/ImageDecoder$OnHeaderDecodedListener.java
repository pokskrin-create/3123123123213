package android.graphics;

/* loaded from: classes2.dex */
public /* synthetic */ interface ImageDecoder$OnHeaderDecodedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
