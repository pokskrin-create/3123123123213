package android.view;

/* loaded from: classes2.dex */
public /* synthetic */ interface OnReceiveContentListener {
    static {
        throw new NoClassDefFoundError();
    }
}
