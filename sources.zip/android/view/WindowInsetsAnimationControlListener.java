package android.view;

/* loaded from: classes2.dex */
public /* synthetic */ interface WindowInsetsAnimationControlListener {
    static {
        throw new NoClassDefFoundError();
    }
}
