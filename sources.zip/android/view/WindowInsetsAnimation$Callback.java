package android.view;

/* loaded from: classes2.dex */
public /* synthetic */ class WindowInsetsAnimation$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
