package android.os;

/* loaded from: classes2.dex */
public /* synthetic */ interface OutcomeReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}
