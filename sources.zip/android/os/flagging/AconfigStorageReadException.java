package android.os.flagging;

/* loaded from: classes2.dex */
public /* synthetic */ class AconfigStorageReadException extends RuntimeException {
    static {
        throw new NoClassDefFoundError();
    }
}
