package androidx.asynclayoutinflater;

/* loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static int alpha = 0x7f03002d;
        public static int font = 0x7f03009f;
        public static int fontProviderAuthority = 0x7f0300a1;
        public static int fontProviderCerts = 0x7f0300a2;
        public static int fontProviderFetchStrategy = 0x7f0300a4;
        public static int fontProviderFetchTimeout = 0x7f0300a5;
        public static int fontProviderPackage = 0x7f0300a6;
        public static int fontProviderQuery = 0x7f0300a7;
        public static int fontStyle = 0x7f0300a9;
        public static int fontVariationSettings = 0x7f0300aa;
        public static int fontWeight = 0x7f0300ab;
        public static int ttcIndex = 0x7f030173;

        private attr() {
        }
    }

    public static final class color {
        public static int notification_action_color_filter = 0x7f05004f;
        public static int notification_icon_bg_color = 0x7f050050;
        public static int ripple_material_light = 0x7f05005c;
        public static int secondary_text_default_material_light = 0x7f05005e;

        private color() {
        }
    }

    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 0x7f060050;
        public static int compat_button_inset_vertical_material = 0x7f060051;
        public static int compat_button_padding_horizontal_material = 0x7f060052;
        public static int compat_button_padding_vertical_material = 0x7f060053;
        public static int compat_control_corner_material = 0x7f060054;
        public static int compat_notification_large_icon_max_height = 0x7f060055;
        public static int compat_notification_large_icon_max_width = 0x7f060056;
        public static int notification_action_icon_size = 0x7f060066;
        public static int notification_action_text_size = 0x7f060067;
        public static int notification_big_circle_margin = 0x7f060068;
        public static int notification_content_margin_start = 0x7f060069;
        public static int notification_large_icon_height = 0x7f06006a;
        public static int notification_large_icon_width = 0x7f06006b;
        public static int notification_main_column_padding_top = 0x7f06006c;
        public static int notification_media_narrow_margin = 0x7f06006d;
        public static int notification_right_icon_size = 0x7f06006e;
        public static int notification_right_side_padding_top = 0x7f06006f;
        public static int notification_small_icon_background_padding = 0x7f060070;
        public static int notification_small_icon_size_as_large = 0x7f060071;
        public static int notification_subtext_size = 0x7f060072;
        public static int notification_top_pad = 0x7f060073;
        public static int notification_top_pad_large_text = 0x7f060074;

        private dimen() {
        }
    }

    public static final class drawable {
        public static int notification_action_background = 0x7f07007d;
        public static int notification_bg = 0x7f07007e;
        public static int notification_bg_low = 0x7f07007f;
        public static int notification_bg_low_normal = 0x7f070080;
        public static int notification_bg_low_pressed = 0x7f070081;
        public static int notification_bg_normal = 0x7f070082;
        public static int notification_bg_normal_pressed = 0x7f070083;
        public static int notification_icon_background = 0x7f070084;
        public static int notification_template_icon_bg = 0x7f070086;
        public static int notification_template_icon_low_bg = 0x7f070087;
        public static int notification_tile_bg = 0x7f070088;
        public static int notify_panel_notification_icon_bg = 0x7f070089;

        private drawable() {
        }
    }

    public static final class id {
        public static int action_container = 0x7f08002f;
        public static int action_divider = 0x7f080031;
        public static int action_image = 0x7f080032;
        public static int action_text = 0x7f080038;
        public static int actions = 0x7f080039;
        public static int async = 0x7f080045;
        public static int blocking = 0x7f080048;
        public static int chronometer = 0x7f080057;
        public static int forever = 0x7f08006d;
        public static int icon = 0x7f080075;
        public static int icon_group = 0x7f080077;
        public static int info = 0x7f08007b;
        public static int italic = 0x7f08007c;
        public static int line1 = 0x7f080080;
        public static int line3 = 0x7f080081;
        public static int normal = 0x7f08008c;
        public static int notification_background = 0x7f08008d;
        public static int notification_main_column = 0x7f08008e;
        public static int notification_main_column_container = 0x7f08008f;
        public static int right_icon = 0x7f08009d;
        public static int right_side = 0x7f08009e;
        public static int tag_transition_group = 0x7f0800d0;
        public static int tag_unhandled_key_event_manager = 0x7f0800d1;
        public static int tag_unhandled_key_listeners = 0x7f0800d2;
        public static int text = 0x7f0800d4;
        public static int text2 = 0x7f0800d5;
        public static int time = 0x7f0800d8;
        public static int title = 0x7f0800d9;

        private id() {
        }
    }

    public static final class integer {
        public static int status_bar_notification_info_maxnum = 0x7f090007;

        private integer() {
        }
    }

    public static final class layout {
        public static int notification_action = 0x7f0b0023;
        public static int notification_action_tombstone = 0x7f0b0024;
        public static int notification_template_custom_big = 0x7f0b002b;
        public static int notification_template_icon_group = 0x7f0b002c;
        public static int notification_template_part_chronometer = 0x7f0b0030;
        public static int notification_template_part_time = 0x7f0b0031;

        private layout() {
        }
    }

    public static final class string {
        public static int status_bar_notification_info_overflow = 0x7f0e004f;

        private string() {
        }
    }

    public static final class style {
        public static int TextAppearance_Compat_Notification = 0x7f0f010e;
        public static int TextAppearance_Compat_Notification_Info = 0x7f0f010f;
        public static int TextAppearance_Compat_Notification_Line2 = 0x7f0f0111;
        public static int TextAppearance_Compat_Notification_Time = 0x7f0f0114;
        public static int TextAppearance_Compat_Notification_Title = 0x7f0f0116;
        public static int Widget_Compat_NotificationActionContainer = 0x7f0f0182;
        public static int Widget_Compat_NotificationActionText = 0x7f0f0183;

        private style() {
        }
    }

    public static final class styleable {
        public static int ColorStateListItem_alpha = 0x00000003;
        public static int ColorStateListItem_android_alpha = 0x00000001;
        public static int ColorStateListItem_android_color = 0x00000000;
        public static int ColorStateListItem_android_lStar = 0x00000002;
        public static int ColorStateListItem_lStar = 0x00000004;
        public static int FontFamilyFont_android_font = 0x00000000;
        public static int FontFamilyFont_android_fontStyle = 0x00000002;
        public static int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static int FontFamilyFont_android_fontWeight = 0x00000001;
        public static int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static int FontFamilyFont_font = 0x00000005;
        public static int FontFamilyFont_fontStyle = 0x00000006;
        public static int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static int FontFamilyFont_fontWeight = 0x00000008;
        public static int FontFamilyFont_ttcIndex = 0x00000009;
        public static int FontFamily_fontProviderAuthority = 0x00000000;
        public static int FontFamily_fontProviderCerts = 0x00000001;
        public static int FontFamily_fontProviderFallbackQuery = 0x00000002;
        public static int FontFamily_fontProviderFetchStrategy = 0x00000003;
        public static int FontFamily_fontProviderFetchTimeout = 0x00000004;
        public static int FontFamily_fontProviderPackage = 0x00000005;
        public static int FontFamily_fontProviderQuery = 0x00000006;
        public static int FontFamily_fontProviderSystemFontFamily = 0x00000007;
        public static int GradientColorItem_android_color = 0x00000000;
        public static int GradientColorItem_android_offset = 0x00000001;
        public static int GradientColor_android_centerColor = 0x00000007;
        public static int GradientColor_android_centerX = 0x00000003;
        public static int GradientColor_android_centerY = 0x00000004;
        public static int GradientColor_android_endColor = 0x00000001;
        public static int GradientColor_android_endX = 0x0000000a;
        public static int GradientColor_android_endY = 0x0000000b;
        public static int GradientColor_android_gradientRadius = 0x00000005;
        public static int GradientColor_android_startColor = 0x00000000;
        public static int GradientColor_android_startX = 0x00000008;
        public static int GradientColor_android_startY = 0x00000009;
        public static int GradientColor_android_tileMode = 0x00000006;
        public static int GradientColor_android_type = 0x00000002;
        public static int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, com.celltrionph.ghr_app.R.attr.alpha, com.celltrionph.ghr_app.R.attr.lStar};
        public static int[] FontFamily = {com.celltrionph.ghr_app.R.attr.fontProviderAuthority, com.celltrionph.ghr_app.R.attr.fontProviderCerts, com.celltrionph.ghr_app.R.attr.fontProviderFallbackQuery, com.celltrionph.ghr_app.R.attr.fontProviderFetchStrategy, com.celltrionph.ghr_app.R.attr.fontProviderFetchTimeout, com.celltrionph.ghr_app.R.attr.fontProviderPackage, com.celltrionph.ghr_app.R.attr.fontProviderQuery, com.celltrionph.ghr_app.R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, com.celltrionph.ghr_app.R.attr.font, com.celltrionph.ghr_app.R.attr.fontStyle, com.celltrionph.ghr_app.R.attr.fontVariationSettings, com.celltrionph.ghr_app.R.attr.fontWeight, com.celltrionph.ghr_app.R.attr.ttcIndex};
        public static int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}
