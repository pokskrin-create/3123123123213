package androidx.appcompat.view;

/* loaded from: classes.dex */
public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
