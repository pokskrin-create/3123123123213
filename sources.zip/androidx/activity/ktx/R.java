package androidx.activity.ktx;

/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}
