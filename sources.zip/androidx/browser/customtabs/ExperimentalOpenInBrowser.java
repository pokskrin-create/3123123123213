package androidx.browser.customtabs;

/* loaded from: classes.dex */
public @interface ExperimentalOpenInBrowser {
}
