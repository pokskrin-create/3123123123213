package androidx.browser.trusted.splashscreens;

/* loaded from: classes.dex */
public final class SplashScreenVersion {
    public static final String V1 = "androidx.browser.trusted.category.TrustedWebActivitySplashScreensV1";

    private SplashScreenVersion() {
    }
}
