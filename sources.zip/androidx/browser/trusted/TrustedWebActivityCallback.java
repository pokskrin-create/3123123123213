package androidx.browser.trusted;

import android.os.Bundle;

/* loaded from: classes.dex */
public abstract class TrustedWebActivityCallback {
    public abstract void onExtraCallback(String str, Bundle bundle);
}
