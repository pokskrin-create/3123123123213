package androidx.browser;

/* loaded from: classes.dex */
public final class R {

    public static final class color {
        public static int browser_actions_bg_grey = 0x7f050026;
        public static int browser_actions_divider_color = 0x7f050027;
        public static int browser_actions_text_color = 0x7f050028;
        public static int browser_actions_title_color = 0x7f050029;

        private color() {
        }
    }

    public static final class dimen {
        public static int browser_actions_context_menu_max_width = 0x7f06004e;
        public static int browser_actions_context_menu_min_padding = 0x7f06004f;

        private dimen() {
        }
    }

    public static final class id {
        public static int browser_actions_header_text = 0x7f08004b;
        public static int browser_actions_menu_item_icon = 0x7f08004c;
        public static int browser_actions_menu_item_text = 0x7f08004d;
        public static int browser_actions_menu_items = 0x7f08004e;
        public static int browser_actions_menu_view = 0x7f08004f;

        private id() {
        }
    }

    public static final class layout {
        public static int browser_actions_context_menu_page = 0x7f0b001c;
        public static int browser_actions_context_menu_row = 0x7f0b001d;

        private layout() {
        }
    }

    public static final class string {
        public static int copy_toast_msg = 0x7f0e0036;
        public static int fallback_menu_item_copy_link = 0x7f0e003a;
        public static int fallback_menu_item_open_in_browser = 0x7f0e003b;
        public static int fallback_menu_item_share_link = 0x7f0e003c;

        private string() {
        }
    }

    public static final class xml {
        public static int image_share_filepaths = 0x7f110001;

        private xml() {
        }
    }

    private R() {
    }
}
